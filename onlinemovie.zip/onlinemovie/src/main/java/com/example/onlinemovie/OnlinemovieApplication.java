package com.example.onlinemovie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinemovieApplication {

  public static void main(String[] args) {
    SpringApplication.run(OnlinemovieApplication.class, args);
  }

}
