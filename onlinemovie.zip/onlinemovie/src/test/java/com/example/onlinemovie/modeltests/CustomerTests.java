package com.example.onlinemovie.modeltests;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

import com.example.onlinemovie.model.Cart;
import com.example.onlinemovie.model.Customer;
import com.example.onlinemovie.repository.CartRepository;
import com.example.onlinemovie.repository.CustomerRepository;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest
class CustomerTests {
	
	@Autowired
	CustomerRepository repository;

	@Test
	void test() {
		//fail("Not yet implemented");
		
		System.out.println("good to go");
		Customer cs=new Customer();
		cs.setAddress("11-148, Main Road");
		cs.setContact("8125956409");
		cs.setEmail("sivasankar123@gmail.com");
		cs.setName("Siva Sankar");
		cs.setPassword("Siva@123456");
		
		
	
		assertNotNull(repository.save(cs));
	}

}
