package com.example.onlinemovie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinemovieApplicationTests {

	@Test
	void contextLoads() {
	}

}
