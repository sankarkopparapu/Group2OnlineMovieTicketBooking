package com.example.onlinemovie.modeltests;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

import com.example.onlinemovie.model.Admin;
import com.example.onlinemovie.model.Cart;
import com.example.onlinemovie.repository.AdminRepository;
import com.example.onlinemovie.repository.CartRepository;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest
class CartTests {
	
	@Autowired
	CartRepository repository;
	
    
	@Test
	void test() {
		//fail("Not yet implemented");
		System.out.println("inside the test");
		Cart c=new Cart();
		
		c.setPrice(350);
		c.setId(1);
		c.setQuantity(1);
		c.setProduct(null);
	
		assertNotNull(repository.save(c));
	}

}
